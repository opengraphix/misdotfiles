

These Beamer themes build heavily upon the help I got from the users of [TeX.SX](http://tex.stackexchange.com) answering my questions. More specifically:

- [Claudio Fiandrino](http://tex.stackexchange.com/users/13304/claudio-fiandrino)'s answer at http://tex.stackexchange.com/a/146682/21963
- [samcarter](http://tex.stackexchange.com/users/36296/samcarter)'s answer at http://tex.stackexchange.com/a/181248/21963
- [cfr](http://tex.stackexchange.com/users/39222/cfr)'s answer at http://tex.stackexchange.com/a/217885/21963

Because of all StackExchange user content being licensed under the [CC-BY-SA](http://creativecommons.org/licenses/by-sa/3.0) license, these themes are too. I believe that this text file makes me comply with the requirements of the license.

The Creative Commons website also told me to include this blurb:

This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.
